﻿import React, { Component } from "react";

class Results extends Component {
    render() {
        return (
            <div>
                <h2>Result</h2>
            </div>
        );
    }
}

export default Results;