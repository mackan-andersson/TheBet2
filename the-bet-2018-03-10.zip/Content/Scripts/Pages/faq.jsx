﻿import React, { Component } from "react";

class Faq extends Component {
    render() {
        return (
            <div>
                <h2>Faq</h2>
            </div>
        );
    }
}

export default Faq;