﻿import React, { Component } from "react";

class Table extends Component {
    render() {
        return (
            <div>
                <h2>Table</h2>
            </div>
        );
    }
}

export default Table;